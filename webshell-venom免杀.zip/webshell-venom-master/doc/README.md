自己当时写的文章,包含了脚本写作的一些思路跟方法

1.利用随机异或无限免杀d盾:
https://yzddmr6.tk/2019/08/11/webshell-venom-1-0/

2.利用随机异或无限免杀d盾 更新至2.0
https://yzddmr6.tk/2019/08/11/webshell-venom-2-0/

3.无限免杀D盾脚本之aspx
https://yzddmr6.tk/2019/08/11/webshell-venom-aspx/

4.一键吊打D盾(免杀一句话无限生成)
https://yzddmr6.tk/2019/08/12/webshell-venom/

5.一键吊打D盾(webshell-venom 3.0 发布)
https://yzddmr6.tk/2019/08/12/webshell-venom-3-0-1/

6.webshell-venom 3.1/3.2 紧急更新日志
https://yzddmr6.tk/2019/08/13/webshell-venom-3-1-3-2/

7.webshell-venom 4.0 发布：这一次，干翻一切
https://yzddmr6.tk/2019/08/13/webshell-venom-4-0/
